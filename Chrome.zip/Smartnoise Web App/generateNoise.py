import json
import random

width = 1920  # Set the width of the canvas
height = 1080  # Set the height of the canvas
number_of_frames = 10

noise_data = []

for _ in range(number_of_frames):
    frame_data = []
    for _ in range(width * height):
        gray = random.randint(0, 255)
        frame_data.extend([gray, gray, gray, 255])
    noise_data.append(frame_data)

with open("noiseData.json", "w") as f:
    json.dump(noise_data, f)


#gör istället 100k rader. 
#randomizea en skärm i taget rad för rad. 
