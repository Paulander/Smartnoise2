const toggleOverlayButton = document.getElementById("toggleOverlay");
const toggleAudioButton   = document.getElementById("toggleAudio");

const volumeSlider = document.getElementById('volumeSlider');
const pixelSlider  = document.getElementById('pixelSlider');

toggleOverlayButton.addEventListener('click', () => {
  const noiseType = document.getElementById('noiseType').value;
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.tabs.sendMessage(tabs[0].id, { action: 'toggleOverlay', noiseType: noiseType });
  });
});

const body = document.body;

function toggleMode() {
  const body = document.body;
  body.classList.toggle("dark-mode");

  const lightModeIcon = document.getElementById("lightModeIcon");
  const darkModeIcon = document.getElementById("darkModeIcon");

  lightModeIcon.style.display = body.classList.contains("dark-mode") ? "none" : "flex";
  darkModeIcon.style.display = body.classList.contains("dark-mode") ? "flex" : "none";
}

const modeToggle = document.getElementById("modeToggle");
modeToggle.addEventListener("click", toggleMode);



chrome.runtime.onInstalled.addListener(() => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.tabs.sendMessage(tabs[0].id, { action: 'initOverlay' });
  });
});

chrome.runtime.onStartup.addListener(() => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.tabs.sendMessage(tabs[0].id, { action: 'initOverlay' });
  });
});

const audioElement = new Audio('white_noise.mp3');
audioElement.loop = true;

toggleAudioButton.addEventListener('click', () => {
  toggleAudio();
});


//Sliders -- create objects

volumeSlider.addEventListener('input', (event) => {
  setVolume(event.target.value);
});

pixelSlider.addEventListener('input', updatePixelSlider);

function updatePixelSlider() {
  const xStepSize = parseInt(pixelSlider.value);
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.tabs.sendMessage(tabs[0].id, { action: 'updatePixelSlider', xStepSize: xStepSize });
  });
}


//Audio control

function toggleAudio() {
  if (audioElement.paused) {
    audioElement.play();
    toggleAudioButton.classList.remove("active"); // Remove the "active" class

  } else {
    audioElement.pause();
    toggleAudioButton.classList.add("active"); // Remove the "active" class

  }
}

function setVolume(volume) {
  audioElement.volume = volume;
}
