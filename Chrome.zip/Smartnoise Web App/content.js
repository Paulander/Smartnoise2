let overlay = null;
let animationFrameId = null;
let noiseType = 'white';
let arraysData = [];
let xStepSize = 4; // 50% noise


fetch(chrome.runtime.getURL('arraysData.json'))
  .then((response) => response.json())
  .then((data) => {
    arraysData = data;
  });


//Todo: modify for different noises.
function createOverlay() {
  overlay = document.createElement('canvas');
  overlay.style.position = 'fixed';
  overlay.style.top = '0';
  overlay.style.left = '0';
  overlay.style.width = '100%';
  overlay.style.height = '100%';
  overlay.style.zIndex = '999999';
  overlay.style.pointerEvents = 'none';
  overlay.style.opacity = '0.5';
  overlay.style.display = 'none';

  // Set the canvas size to the window size
  overlay.width = window.innerWidth;
  overlay.height = window.innerHeight;

  document.body.appendChild(overlay);
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'toggleOverlay') {
    if (!overlay) {
      createOverlay();
    }
    noiseType = request.noiseType;
    toggleOverlay();
  }

    if (request.action === 'updatePixelSlider') {
    xStepSize = 12 - request.xStepSize;
    if (overlay && overlay.style.display === 'block') {
      updateNoise();
    }
    }
});

//requestAnimationFrame Is called at each screen refresh. 

function updateNoise() {
  if (!overlay) return;

  const imageData = createNoiseOverlay(arraysData);
  const ctx = overlay.getContext('2d');
  ctx.putImageData(imageData, 0, 0);
}

function updateNoiseLoop() {
  updateNoise();
  animationFrameId = requestAnimationFrame(updateNoiseLoop);
}

function toggleOverlay() {
  console.log('Toggling overlay with noise type:', noiseType);

  if (overlay.style.display === 'none') {
    overlay.style.display = 'block';
    updateNoise();
    animationFrameId = requestAnimationFrame(updateNoiseLoop);
    toggleOverlayButton.classList.add("active"); // Add the "active" class

  } else {
    overlay.style.display = 'none';
    cancelAnimationFrame(animationFrameId);
    animationFrameId = null;
    toggleOverlayButton.classList.remove("active"); // Add the "active" class

  }
}

function createNoiseOverlay(arraysData) {
  const width = window.innerWidth;
  const height = window.innerHeight;
  const numberOfLines = height;

  const imageData = new ImageData(width, height);

  // To optimize we have to compromize between realtime performance
  // and data size (i.e. pregenerated noise). Currently my best
  // solution is to have pregenerated lines that I draw starting from 
  // a random index, by simply looping through lines.
  // The noise level (in this implementation, in line with the research)
  // is controlled by just applying noise to 1/<step size> of the pixels.
  // To avoid "lines" (artefacts) in the noise we randomize the starting 
  // x value on each lines in [0, step size - 1]

  // Comment: another approach would be to draw noise for all pixels, 
  // but varying the opacity.

  let randomStartIndex = Math.floor(Math.random() * (arraysData.length - numberOfLines));
  let xStep = Math.floor(Math.random() * 4);

  for (let y = 0; y < height; y++) {
    const arrayIndex = (randomStartIndex + y) % arraysData.length;
    const arrayData = arraysData[arrayIndex];

    for (let x = 0; x < width; x += xStep) {
      const gray = arrayData[x % 1920];
      const imageDataIndex = (x + y * width) * 4;

      imageData.data[imageDataIndex] = gray;
      imageData.data[imageDataIndex + 1] = gray;
      imageData.data[imageDataIndex + 2] = gray;
      imageData.data[imageDataIndex + 3] = 255;

      if(xStepSize > 1)
      {
        xStep = Math.floor(Math.random()*xStepSize);
      }
      else
      {
        xStep = 1; 
      }
    }
  }

  return imageData;
}
