import json
import random

width = 1920  # Set the width of the canvas
number_of_arrays = 5000

arrays_data = []

for _ in range(number_of_arrays):
    array_data = [random.randint(0, 255) for _ in range(width)]
    arrays_data.append(array_data)

with open("arraysData.json", "w") as f:
    json.dump(arrays_data, f)
